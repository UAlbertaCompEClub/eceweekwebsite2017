
				<!-- Footer -->
					<div id="footer">
						<ul class="copyright">
							<li>&copy; ECE Week</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
						</ul>
					</div>

			</div>

		<!-- Scripts -->
			<script src="http://cdn.rawgit.com/UAlbertaCompEClub/eceweekwebsite2017/master/static/assets/js/jquery.min.js"></script>
			<script src="http://cdn.rawgit.com/UAlbertaCompEClub/eceweekwebsite2017/master/static/assets/js/skel.min.js"></script>
			<script src="http://cdn.rawgit.com/UAlbertaCompEClub/eceweekwebsite2017/master/static/assets/js/skel-viewport.min.js"></script>
			<script src="http://cdn.rawgit.com/UAlbertaCompEClub/eceweekwebsite2017/master/static/assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="http://cdn.rawgit.com/UAlbertaCompEClub/eceweekwebsite2017/master/static/assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="http://cdn.rawgit.com/UAlbertaCompEClub/eceweekwebsite2017/master/static/assets/js/main.js"></script>

	</body>
</html>
